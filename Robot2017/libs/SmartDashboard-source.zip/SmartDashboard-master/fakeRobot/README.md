# LiveWindow Fake Robot

This is for testing the LiveWindow funcitonality in the SmartDashboard.
