package edu.wpi.first.smartdashboard.gui;


/**
 * @author Joe Grinstead
 */
public abstract class StaticWidget extends DisplayElement {

}
